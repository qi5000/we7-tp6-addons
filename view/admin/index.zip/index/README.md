存放后台管理系统前端静态资源

/addons/liang_tp_applet/view/admin/index/static
/addons/liang_tp_applet/view/admin/index/index.html